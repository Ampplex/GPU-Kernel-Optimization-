"""GPU kernel optimization project."""
