# GPU Kernel Optimization with PyTorch and Triton

A hands-on GPU-kernel project focused on correctness-first optimization of matrix multiplication (GEMM) and memory-efficient scaled dot-product attention.

> **Status:** starter implementation. Run benchmarks on a supported NVIDIA GPU before reporting any performance numbers. This repository does not claim a particular speedup by default.

## Goals

- Establish PyTorch reference implementations for GEMM and attention.
- Implement a tiled Triton GEMM kernel.
- Implement a forward-only FlashAttention-style Triton kernel using tiled computation and online softmax.
- Validate numerical correctness against PyTorch.
- Benchmark with warm-up and repeated measurements, reporting latency and speedup.

## Repository layout

```text
src/
  kernels.py          Triton GEMM and forward attention kernels
  reference.py        PyTorch reference implementations
benchmarks/
  benchmark_gemm.py   GEMM correctness and latency benchmark
  benchmark_attention.py  Attention correctness and latency benchmark
tests/
  test_kernels.py     GPU correctness tests
notebooks/
  colab_quickstart.md Colab setup and run commands
requirements.txt
```

## Requirements

- Python 3.10 or 3.11 recommended
- NVIDIA GPU supported by the installed PyTorch and Triton builds
- CUDA-enabled PyTorch and Triton versions compatible with the runtime

On Google Colab, choose **Runtime → Change runtime type → T4 GPU** (or another available NVIDIA GPU), then run:

```bash
!git clone <YOUR_GITHUB_REPOSITORY_URL>
%cd gpu-kernel-optimization
!pip install -r requirements.txt
!python benchmarks/benchmark_gemm.py
!python benchmarks/benchmark_attention.py
```

If you are uploading the ZIP directly to Colab instead of using GitHub, upload and extract it, then `cd` into the extracted directory.

## Kernels

### 1. Tiled GEMM

Computes `C = A @ B` for two-dimensional tensors. The Triton kernel loads blocks of A and B, accumulates products in FP32, and writes the result in the requested output dtype. Inputs must be on a CUDA device.

### 2. FlashAttention-style forward pass

Computes scaled dot-product attention without materializing the complete score matrix. It processes key/value blocks and maintains online softmax statistics. This implementation is **forward-only**; it does not provide a custom backward kernel.

## Run

```bash
python benchmarks/benchmark_gemm.py --m 1024 --n 1024 --k 1024 --dtype fp16
python benchmarks/benchmark_attention.py --batch 1 --heads 4 --seq-len 512 --head-dim 64 --dtype fp16
pytest -q
```

Benchmarks automatically stop with a clear message if CUDA is unavailable. Do not benchmark on CPU and label the results as GPU-kernel performance.

## Benchmark methodology

- Verify outputs against PyTorch before timing.
- Warm up kernels before measurement.
- Use CUDA events through `triton.testing.do_bench` when available.
- Report GPU model, software versions, shapes, dtype, baseline latency, custom latency, and speedup.
- Repeat across several shapes. A custom kernel may be slower than PyTorch for some sizes; report results as observed.

## Scope and limitations

- No custom CUDA C++ kernel is included in this initial version.
- No asynchronous CUDA copy pipeline, custom backward attention kernel, or claim of 2.8× speedup is included.
- PyTorch operations may dispatch to highly optimized vendor libraries, so beating the baseline is not guaranteed.
- Triton performance depends on GPU architecture, shapes, tile parameters, and software versions.

## Resume guidance

Only list measured results after running this repository and recording the exact hardware and methodology. A truthful starter description is:

> Implemented tiled GEMM and a forward-only FlashAttention-style kernel in Triton; validated outputs against PyTorch and built repeatable GPU benchmarks for latency and numerical correctness.
