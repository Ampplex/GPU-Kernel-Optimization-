# Google Colab quick start

1. Open a new notebook in Google Colab.
2. Select **Runtime → Change runtime type → T4 GPU** (or any available supported NVIDIA GPU).
3. Upload the project ZIP or clone your GitHub repository.
4. Run:

```python
!pip install -r requirements.txt
!python benchmarks/benchmark_gemm.py --m 1024 --n 1024 --k 1024 --dtype fp16
!python benchmarks/benchmark_attention.py --batch 1 --heads 4 --seq-len 512 --head-dim 64 --dtype fp16
!pytest -q
```

Keep the printed GPU model, tensor shapes, dtype, baseline latency, Triton latency, and speedup in your experiment notes. Run each shape more than once and avoid reporting a speedup without correctness validation.
